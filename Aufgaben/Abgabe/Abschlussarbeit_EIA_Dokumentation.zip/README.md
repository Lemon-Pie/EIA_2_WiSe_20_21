# SoccerSimulator

The game is played by clicking with the mouse:
-click to kick the ball
-wait till ball has reached its target position, then click again to move the players

It is a little bit hard to get the ball into the left goal due to where the mouse position is being measured (not at the top of the mouse but somewhere at the end), but it is possible to score a goal there
It is advised not to click too fast

The App replicates the game between Germany and Portugal at the Euro 2020
If minimal values entered by the user are bigger than the max values they are swapped
